from Tkinter import *


top = Tk()
w, h = 400, 400#top.winfo_screenwidth(), top.winfo_screenheight()
top.geometry("%dx%d+0+0" % (w, h))

clap_settings = ['1 slide forward		   ', '1 slide backward		  ', '2 slides forward', '2 slides backward', 'End presentation		 ', 'Restart presentation',]

#send messages to arduino
def talkToArduino(clap1_var, clap2_var, clap3_var, clap4_var, sensitivity_var, input_range_var):
   #arduinoSerialPort = serial.Serial(12, 9600) #connect to arduino
   clap1_ard = 'a' + str(clap_settings.index(clap1_var.get()))
   clap2_ard = 'b' + str(clap_settings.index(clap2_var.get()))
   clap3_ard = 'c' + str(clap_settings.index(clap3_var.get()))
   clap4_ard = 'd' + str(clap_settings.index(clap4_var.get()))
   sens_ard = 's' + str(sensitivity_var)
   input_ard = 'i' + str(input_range_var)
   print clap1_ard, clap2_ard, clap3_ard, clap4_ard, sens_ard, input_ard

#placeholder function
def donothing():
	filewin = Toplevel(top)
	button = Button(filewin, text="Do nothing button")
	button.pack()
 
top["bg"]="white"

# show "PrezGo" at the top
top.title("PrezGo")

#position variables
PrezGo_x = 100
PrezGo_y = 5
clap1_x = 100
clap1_y = 70
clap2_x = clap1_x
clap2_y = clap1_y + 40
clap3_x = clap2_x
clap3_y = clap2_y + 40
clap4_x = clap3_x
clap4_y = clap3_y + 40
sensitivity_x = clap4_x
sensitivity_y = clap4_y + 50
input_range_x = sensitivity_x
input_range_y = sensitivity_y + 50
save_x = input_range_x
save_y = input_range_y + 50

#set up title PrezGo
PrezGo_label = Label(top, text="PrezGo", bg="white")
PrezGo_label.config(font=("Courier", 44))
PrezGo_label.pack()
PrezGo_label.place(x=PrezGo_x, y=PrezGo_y)



#widgets
clap1_label = Label(top, text="One Clap: ", bg="white")
clap1_label.pack()
clap1_label.place(x=clap1_x, y=clap1_y)
clap1_var = StringVar(top)
clap1_var.set(clap_settings[0])
clap1 = OptionMenu(top, clap1_var, clap_settings[0], clap_settings[1], clap_settings[-2], clap_settings[-1])
clap1["menu"].config(bg="white")
clap1.config(bg="white")
clap1.pack()
clap1.place(x=clap1_x+70, y=clap1_y)
clap2_label = Label(top, text="Two Claps: ", bg="white")
clap2_label.pack()
clap2_label.place(x=clap2_x, y=clap2_y)
clap2_var = StringVar(top)
clap2_var.set(clap_settings[1])
clap2 = OptionMenu(top, clap2_var, clap_settings[1], clap_settings[2], clap_settings[3], clap_settings[-2], clap_settings[-1])
clap2["menu"].config(bg="white")
clap2.config(bg="white")
clap2.pack()
clap2.place(x=clap2_x+70, y=clap2_y)
clap3_label = Label(top, text="Three Claps: ", bg="white")
clap3_label.pack()
clap3_label.place(x=clap3_x, y=clap3_y)
clap3_var = StringVar(top)
clap3_var.set(clap_settings[4])
clap3 = OptionMenu(top, clap3_var, clap_settings[-2], clap_settings[-1])
clap3["menu"].config(bg="white")
clap3.config(bg="white")
clap3.pack()
clap3.place(x=clap3_x+70, y=clap3_y)
clap4_label = Label(top, text="Four Claps: ", bg="white")
clap4_label.pack()
clap4_label.place(x=clap4_x, y=clap4_y)
clap4_var = StringVar(top)
clap4_var.set(clap_settings[-1])
clap4 = OptionMenu(top, clap4_var, clap_settings[-2], clap_settings[-1])
clap4["menu"].config(bg="white")
clap4.config(bg="white")
clap4.pack()
clap4.place(x=clap4_x+70, y=clap4_y)

sensitivity_label = Label(top, text="Sensitivity:", bg="white")
sensitivity_label.pack( side = LEFT)
sensitivity_label.place(x=sensitivity_x, y=sensitivity_y)
sensitivity_var = 0
sensitivity = Scale(top, variable = sensitivity_var, from_=1, to_=3, resolution=1, orient=HORIZONTAL, length=120, bg="white", highlightbackground="white")

sensitivity.pack()
sensitivity.place(x=sensitivity_x + 75, y=sensitivity_y - 13)

input_range_label = Label(top, text="Input Range:", bg="white")
input_range_label.pack( side = LEFT)
input_range_label.place(x=input_range_x, y=input_range_y)
input_range_var = 1
input_range = Scale(top, variable = input_range_var, from_=1, to_=3, resolution=1, orient=HORIZONTAL, length=120, bg="white", highlightbackground="white") 
input_range.pack()
input_range.place(x=input_range_x+75, y=input_range_y-13)

save = Button(top, text ="Save Settings", command = lambda:talkToArduino(clap1_var, clap2_var, clap3_var, clap4_var, sensitivity_var, input_range_var))
save.pack()
save.place(x=save_x + 55, y=save_y)

#menu
menubar = Menu(top)
filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="New", command=donothing)
filemenu.add_command(label="Open", command=donothing)
filemenu.add_command(label="Save", command=donothing)
filemenu.add_command(label="Save as...", command=donothing)
filemenu.add_command(label="Close", command=donothing)

filemenu.add_separator()

filemenu.add_command(label="Exit", command=top.quit)
menubar.add_cascade(label="File", menu=filemenu)
editmenu = Menu(menubar, tearoff=0)
editmenu.add_command(label="Undo", command=donothing)

editmenu.add_separator()

editmenu.add_command(label="Cut", command=donothing)
editmenu.add_command(label="Copy", command=donothing)
editmenu.add_command(label="Paste", command=donothing)
editmenu.add_command(label="Delete", command=donothing)
editmenu.add_command(label="Select All", command=donothing)

menubar.add_cascade(label="Edit", menu=editmenu)
helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label="Help Index", command=donothing)
helpmenu.add_command(label="About...", command=donothing)
menubar.add_cascade(label="Help", menu=helpmenu)

top.config(menu=menubar)

#launch screen
top.mainloop()
