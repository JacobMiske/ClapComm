import serial

ser = serial.Serial("COM4", 9600) #connect to arduino
line = []

while True:
	print 'while'
	for c in ser.read():
		print 'for'
		line.append(c)
		if c == '\n':
			print ("Line: " + line)
			line = []
			break

ser.close()